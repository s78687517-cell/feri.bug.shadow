module.exports = {
  tokens: "8459481961:AAH_HON5zqAumV8rU7UyUQbBqBYhXznd2zA",
  owner: "8049738545",
  port: "2279",
  ipvps: "157.245.155.210"
};