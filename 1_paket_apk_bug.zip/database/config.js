//credit By Limzzzhama 
//no hapus credit ketauan hapus hitam//

module.exports = {
  domain: "https://kalzztamvan-priv-notsepuh.dzhost.my.id", // Ubah jadi Domain panel Mu !!!
  port: "19027" // Ubah Jadi Port Panel Mu !!!
};